# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import account_avatax_unique_code
from . import product
from . import avatax_exemption
from . import res_partner
from . import res_company
from . import account_move
from . import account_fiscal_position
from . import account_external_tax_mixin
